import 'database.dart' as db;

void main() {
  print("Hello World!");
  print("--------");
  print(db.task_DB);
  print("--------");
  print("<task_id>");
  print(db.task_DB[0][0].toString());
  print("<title>");
  print(db.task_DB[0][1]);
  print("<deadline>");
  print(db.task_DB[0][2].toString());
}
