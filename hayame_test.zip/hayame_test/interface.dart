import 'database.dart' as db;

// ——————————
// ----UI----
// 【add button】
// title: __title_UI__
// deadline: __deadline_UI__
// duration: __duration_UI__ (min)
// ———————————

int get_id_UI() {
  int id_UI = 001; //UIで入力するデータに仮定する
  return id_UI;
}

String get_title_UI() {
  String title_UI = "new_title"; //UIで入力するデータに仮定する
  return title_UI;
}

int get_deadline_UI() {
  int deadline_UI = 202306201800; //UIで入力するデータに仮定する
  return deadline_UI;
}

int get_duration_UI() {
  int duration_UI = 30; //UIで入力するデータに仮定する
  return duration_UI;
}
